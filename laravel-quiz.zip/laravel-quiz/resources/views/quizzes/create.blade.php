@extends('layouts.app', ['title' => 'New Quiz'])

@section('content')
    <h1>New Quiz</h1>

    <form method="POST" action="{{ route('quizzes.store') }}" class="card">
        @csrf
        <div class="field">
            <label for="title">Title</label>
            <input type="text" id="title" name="title" required value="{{ old('title') }}">
            @error('title')<small class="error">{{ $message }}</small>@enderror
        </div>
        <div class="field">
            <label for="description">Description (optional)</label>
            <textarea id="description" name="description" rows="3">{{ old('description') }}</textarea>
        </div>
        <div class="actions">
            <button type="submit">Create quiz</button>
            <a href="{{ route('home') }}" class="btn-link">Cancel</a>
        </div>
    </form>
@endsection
